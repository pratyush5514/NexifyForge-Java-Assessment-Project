# NexifyForge Java Assessment Project

Complete repository containing the **HTML/CSS/JS Web Portal** and the **Java Desktop App**.

## Repository Structure
```text
NexifyForge-Java-Assessment-Project-GitHub/
├── web-ui/
│   ├── index.html       # Web portal structure
│   ├── styles.css       # Dark-mode styling
│   └── app.js           # Proctoring, screen recording & admin dashboard logic
├── java-desktop/
│   └── JavaAssessmentApp.java  # Native Java Swing desktop app
├── README.md
└── .gitignore
```

## Quick Start / How to Push to GitHub
1. Initialize git in your local folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: NexifyForge Java Assessment & Proctoring System"
   ```
2. Link to your GitHub repository and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
   git push -u origin main
   ```
