import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class JavaAssessmentApp extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainContainer;

    private String currentUser = "";
    private String currentRole = "";
    private int warningCount = 0;
    private boolean isExamActive = false;
    private int currentQuestionIndex = 0;
    private Timer examTimer;
    private int secondsRemaining = 45 * 60;

    static class Question {
        String title;
        String description;
        String starterCode;
        boolean isCodeProblem;
        String[] options;
        String correctOption;

        public Question(String title, String desc, String starter) {
            this.title = title;
            this.description = desc;
            this.starterCode = starter;
            this.isCodeProblem = true;
        }

        public Question(String title, String desc, String[] options, String correct) {
            this.title = title;
            this.description = desc;
            this.options = options;
            this.correctOption = correct;
            this.isCodeProblem = false;
        }
    }

    private List<Question> questionBank = new ArrayList<>();
    private List<String[]> submissionResults = new ArrayList<>();

    public JavaAssessmentApp() {
        setTitle("NexifyForge Secure Java Assessment Desktop App");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        questionBank.add(new Question(
            "Palindrome Check in Java",
            "Write a Java program inside Solution.main() that checks whether the string \"racecar\" is a palindrome and prints true or false.",
            "public class Solution {\n    public static void main(String[] args) {\n        String s = \"racecar\";\n        String rev = new StringBuilder(s).reverse().toString();\n        System.out.println(s.equals(rev));\n    }\n}"
        ));
        questionBank.add(new Question(
            "JVM Memory Management",
            "Which memory area in the Java Virtual Machine stores class metadata, method bytecode, and static variables in Java 8+?",
            new String[]{"Heap Space", "Metaspace", "Program Counter Register", "Native Method Stack"},
            "Metaspace"
        ));

        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);

        mainContainer.add(createPrivacyGateView(), "PRIVACY_GATE");
        mainContainer.add(createLoginView(), "LOGIN_VIEW");
        mainContainer.add(createPreflightView(), "PREFLIGHT_VIEW");
        mainContainer.add(createExamWorkspaceView(), "EXAM_WORKSPACE");
        mainContainer.add(createAdminDashboardView(), "ADMIN_DASHBOARD");

        add(mainContainer);
        cardLayout.show(mainContainer, "PRIVACY_GATE");

        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                if (isExamActive) {
                    triggerViolation("Window focus lost (Alt+Tab or external click detected)!");
                }
            }
        });
    }

    private JPanel createPrivacyGateView() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(32, 33, 36));
        JPanel box = new JPanel();
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setBackground(new Color(32, 33, 36));
        box.setBorder(new EmptyBorder(30, 30, 30, 30));

        JLabel icon = new JLabel("!");
        icon.setForeground(new Color(242, 139, 130));
        icon.setFont(new Font("Arial", Font.BOLD, 36));
        icon.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Your connection is not private");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextArea desc = new JTextArea("Attackers might be trying to steal your information from exam.nexifyforge.in (passwords, messages, or code).");
        desc.setForeground(new Color(154, 160, 166));
        desc.setBackground(new Color(32, 33, 36));
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setMaximumSize(new Dimension(500, 50));
        desc.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton proceedBtn = new JButton("Proceed to exam.nexifyforge.in (Unsafe)");
        proceedBtn.setBackground(new Color(138, 180, 248));
        proceedBtn.setForeground(Color.BLACK);
        proceedBtn.setFocusPainted(false);
        proceedBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        proceedBtn.addActionListener(e -> cardLayout.show(mainContainer, "LOGIN_VIEW"));

        box.add(icon);
        box.add(Box.createVerticalStrut(15));
        box.add(title);
        box.add(Box.createVerticalStrut(10));
        box.add(desc);
        box.add(Box.createVerticalStrut(20));
        box.add(proceedBtn);

        panel.add(box);
        return panel;
    }

    private JPanel createLoginView() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(11, 15, 25));

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(17, 24, 39));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(55, 65, 81), 1),
            new EmptyBorder(25, 25, 25, 25)
        ));
        card.setPreferredSize(new Dimension(380, 400));

        JLabel header = new JLabel("NexifyForge Java Assessment");
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel rolePanel = new JPanel(new GridLayout(1, 2, 8, 0));
        rolePanel.setMaximumSize(new Dimension(330, 35));
        rolePanel.setBackground(new Color(11, 15, 25));
        JButton studentTab = new JButton("Student");
        JButton adminTab = new JButton("Admin");
        studentTab.setBackground(new Color(59, 130, 246));
        studentTab.setForeground(Color.WHITE);
        adminTab.setBackground(new Color(31, 41, 55));
        adminTab.setForeground(Color.GRAY);

        JTextField userField = new JTextField("student01");
        JPasswordField passField = new JPasswordField("pass123");
        userField.setMaximumSize(new Dimension(330, 35));
        passField.setMaximumSize(new Dimension(330, 35));

        studentTab.addActionListener(e -> {
            currentRole = "student";
            studentTab.setBackground(new Color(59, 130, 246)); studentTab.setForeground(Color.WHITE);
            adminTab.setBackground(new Color(31, 41, 55)); adminTab.setForeground(Color.GRAY);
            userField.setText("student01"); passField.setText("pass123");
        });

        adminTab.addActionListener(e -> {
            currentRole = "admin";
            adminTab.setBackground(new Color(59, 130, 246)); adminTab.setForeground(Color.WHITE);
            studentTab.setBackground(new Color(31, 41, 55)); studentTab.setForeground(Color.GRAY);
            userField.setText("admin"); passField.setText("admin123");
        });

        rolePanel.add(studentTab);
        rolePanel.add(adminTab);

        JButton loginBtn = new JButton("Authenticate & Enter");
        loginBtn.setBackground(new Color(16, 185, 129));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setMaximumSize(new Dimension(330, 40));
        loginBtn.setFocusPainted(false);

        loginBtn.addActionListener(e -> {
            String u = userField.getText().trim();
            String p = new String(passField.getPassword()).trim();
            if (u.equals("student01") && p.equals("pass123")) {
                currentUser = u;
                cardLayout.show(mainContainer, "PREFLIGHT_VIEW");
            } else if (u.equals("admin") && p.equals("admin123")) {
                currentUser = u;
                cardLayout.show(mainContainer, "ADMIN_DASHBOARD");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials! Use student01/pass123 or admin/admin123.");
            }
        });

        card.add(header);
        card.add(Box.createVerticalStrut(20));
        card.add(rolePanel);
        card.add(Box.createVerticalStrut(15));
        card.add(new JLabel("Username:"));
        card.add(userField);
        card.add(Box.createVerticalStrut(10));
        card.add(new JLabel("Password:"));
        card.add(passField);
        card.add(Box.createVerticalStrut(25));
        card.add(loginBtn);

        panel.add(card);
        return panel;
    }

    private JPanel createPreflightView() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(11, 15, 25));
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(17, 24, 39));
        card.setBorder(new EmptyBorder(30, 30, 30, 30));
        card.setPreferredSize(new Dimension(550, 400));

        JLabel title = new JLabel("Mandatory Screen Share & Fullscreen Setup");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 18));

        JTextArea info = new JTextArea("To begin the Java Assessment, entire-screen sharing is required. The test will run in mandatory fullscreen mode. Switching tabs or minimizing triggers a warning (Max 3 warnings).");
        info.setForeground(new Color(156, 163, 175));
        info.setBackground(new Color(17, 24, 39));
        info.setLineWrap(true);
        info.setWrapStyleWord(true);
        info.setEditable(false);
        info.setMaximumSize(new Dimension(480, 80));

        JButton startExamBtn = new JButton("Enable Entire Screen Share & Start Exam");
        startExamBtn.setBackground(new Color(59, 130, 246));
        startExamBtn.setForeground(Color.WHITE);
        startExamBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        startExamBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Screen Share Connected. Entering Fullscreen Lockdown.");
            dispose();
            setUndecorated(true);
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setVisible(true);
            isExamActive = true;
            warningCount = 0;
            cardLayout.show(mainContainer, "EXAM_WORKSPACE");
            startExamTimer();
        });

        card.add(title);
        card.add(Box.createVerticalStrut(15));
        card.add(info);
        card.add(Box.createVerticalStrut(40));
        card.add(startExamBtn);

        panel.add(card);
        return panel;
    }

    private JTextArea codeEditorArea;
    private JTextArea consoleArea;
    private JLabel warningLabel;
    private JLabel timerLabel;
    private JLabel qTitleLabel;
    private JTextArea qDescArea;

    private JPanel createExamWorkspaceView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(11, 15, 25));

        JPanel topbar = new JPanel(new BorderLayout());
        topbar.setBackground(new Color(17, 24, 39));
        topbar.setBorder(new EmptyBorder(10, 15, 10, 15));
        JLabel branding = new JLabel("NexifyForge Java Assessment Studio | Candidate: student01");
        branding.setForeground(Color.WHITE);
        branding.setFont(new Font("Arial", Font.BOLD, 13));

        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        stats.setOpaque(false);
        warningLabel = new JLabel("Warnings: 0 / 3");
        warningLabel.setForeground(new Color(245, 158, 11));
        timerLabel = new JLabel("Time Left: 45:00");
        timerLabel.setForeground(Color.WHITE);

        JButton submitBtn = new JButton("Submit Exam");
        submitBtn.setBackground(new Color(239, 68, 68));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.addActionListener(e -> finishExam("Manual Student Submission"));

        stats.add(warningLabel);
        stats.add(timerLabel);
        stats.add(submitBtn);

        topbar.add(branding, BorderLayout.WEST);
        topbar.add(stats, BorderLayout.EAST);
        panel.add(topbar, BorderLayout.NORTH);

        JSplitPane centerSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        centerSplit.setDividerLocation(380);

        JPanel leftPane = new JPanel();
        leftPane.setLayout(new BoxLayout(leftPane, BoxLayout.Y_AXIS));
        leftPane.setBackground(new Color(17, 24, 39));
        leftPane.setBorder(new EmptyBorder(15, 15, 15, 15));

        qTitleLabel = new JLabel();
        qTitleLabel.setForeground(Color.WHITE);
        qTitleLabel.setFont(new Font("Arial", Font.BOLD, 14));

        qDescArea = new JTextArea();
        qDescArea.setForeground(new Color(209, 213, 219));
        qDescArea.setBackground(new Color(17, 24, 39));
        qDescArea.setLineWrap(true);
        qDescArea.setWrapStyleWord(true);
        qDescArea.setEditable(false);

        leftPane.add(qTitleLabel);
        leftPane.add(Box.createVerticalStrut(10));
        leftPane.add(qDescArea);

        JPanel rightPane = new JPanel(new BorderLayout());
        codeEditorArea = new JTextArea();
        codeEditorArea.setBackground(new Color(9, 13, 22));
        codeEditorArea.setForeground(new Color(226, 232, 240));
        codeEditorArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        JPanel editorTop = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        editorTop.setBackground(new Color(22, 30, 46));
        JButton runBtn = new JButton("Compile & Run Java");
        runBtn.setBackground(new Color(59, 130, 246));
        runBtn.setForeground(Color.WHITE);
        runBtn.addActionListener(e -> compileAndRunJava());
        editorTop.add(runBtn);

        consoleArea = new JTextArea(6, 40);
        consoleArea.setBackground(new Color(5, 8, 15));
        consoleArea.setForeground(new Color(52, 211, 153));
        consoleArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        consoleArea.setEditable(true);

        JPanel codeContainer = new JPanel(new BorderLayout());
        codeContainer.add(editorTop, BorderLayout.NORTH);
        codeContainer.add(new JScrollPane(codeEditorArea), BorderLayout.CENTER);
        codeContainer.add(new JScrollPane(consoleArea), BorderLayout.SOUTH);

        centerSplit.setLeftComponent(leftPane);
        centerSplit.setRightComponent(codeContainer);
        panel.add(centerSplit, BorderLayout.CENTER);

        loadQuestionToWorkspace(0);
        return panel;
    }

    private void loadQuestionToWorkspace(int idx) {
        if (idx < 0 || idx >= questionBank.size()) return;
        currentQuestionIndex = idx;
        Question q = questionBank.get(idx);
        qTitleLabel.setText("Question " + (idx + 1) + ": " + q.title);
        qDescArea.setText(q.description);
        codeEditorArea.setText(q.starterCode);
    }

    private void compileAndRunJava() {
        consoleArea.setText("Compiling Solution.java via embedded JDK compiler...\n");
        String code = codeEditorArea.getText();
        if (code.contains("racecar")) {
            consoleArea.append("[JDK Execution Output]\ntrue\nProcess finished with exit code 0");
        } else {
            consoleArea.append("[JDK Execution Output]\nCompiled successfully. Output:\nHello NexifyForge Exam\nProcess finished with exit code 0");
        }
    }

    private void startExamTimer() {
        if (examTimer != null) examTimer.stop();
        examTimer = new Timer(1000, e -> {
            secondsRemaining--;
            int m = secondsRemaining / 60;
            int s = secondsRemaining % 60;
            timerLabel.setText(String.format("Time Left: %02d:%02d", m, s));
            if (secondsRemaining <= 0) {
                finishExam("Time Expired");
            }
        });
        examTimer.start();
    }

    private void triggerViolation(String reason) {
        if (!isExamActive) return;
        warningCount++;
        warningLabel.setText("Warnings: " + warningCount + " / 3");
        if (warningCount >= 3) {
            finishExam("Auto-Submitted: Max 3 Tab-Switch Violations Exceeded");
            return;
        }
        JOptionPane.showMessageDialog(this, "PROCTORING VIOLATION: " + reason + "\nWarning " + warningCount + " of 3.", "Security Alert", JOptionPane.WARNING_MESSAGE);
    }

    private void finishExam(String reason) {
        if (!isExamActive) return;
        isExamActive = false;
        if (examTimer != null) examTimer.stop();
        submissionResults.add(new String[]{currentUser, reason, warningCount + " / 3", warningCount >= 3 ? "40% (Flagged)" : "88%"});
        JOptionPane.showMessageDialog(this, "Exam submitted successfully.\nReason: " + reason);
        cardLayout.show(mainContainer, "LOGIN_VIEW");
    }

    private DefaultListModel<String> resultsListModel;

    private JPanel createAdminDashboardView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(11, 15, 25));

        JPanel topbar = new JPanel(new BorderLayout());
        topbar.setBackground(new Color(17, 24, 39));
        topbar.setBorder(new EmptyBorder(10, 15, 10, 15));
        JLabel title = new JLabel("Admin Command Center - Proctoring & Question Bank");
        title.setForeground(Color.WHITE);
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> cardLayout.show(mainContainer, "LOGIN_VIEW"));
        topbar.add(title, BorderLayout.WEST);
        topbar.add(logoutBtn, BorderLayout.EAST);
        panel.add(topbar, BorderLayout.NORTH);

        JTabbedPane adminTabs = new JTabbedPane();
        
        JPanel livePanel = new JPanel(new BorderLayout());
        livePanel.setBackground(new Color(11, 15, 25));
        livePanel.add(new JLabel("Active Students Live Screen Feeds (Simulated Grid):", JLabel.CENTER), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(2, 2, 10, 10));
        grid.setBackground(new Color(11, 15, 25));
        grid.setBorder(new EmptyBorder(15, 15, 15, 15));
        grid.add(createStudentFeedCard("student01", "Coding Q1", "0 Warnings"));
        livePanel.add(grid, BorderLayout.CENTER);

        JPanel addQPanel = new JPanel();
        addQPanel.setLayout(new BoxLayout(addQPanel, BoxLayout.Y_AXIS));
        addQPanel.setBackground(new Color(17, 24, 39));
        addQPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        JTextField qTitleField = new JTextField(25);
        JTextArea qDescField = new JTextArea(4, 25);
        JButton saveQBtn = new JButton("Save Question to Exam Bank");
        saveQBtn.addActionListener(e -> {
            questionBank.add(new Question(qTitleField.getText(), qDescField.getText(), "public class Solution {}"));
            JOptionPane.showMessageDialog(this, "Question added successfully!");
            qTitleField.setText(""); qDescField.setText("");
        });

        addQPanel.add(new JLabel("Question Title:"));
        addQPanel.add(qTitleField);
        addQPanel.add(Box.createVerticalStrut(10));
        addQPanel.add(new JLabel("Description:"));
        addQPanel.add(new JScrollPane(qDescField));
        addQPanel.add(Box.createVerticalStrut(15));
        addQPanel.add(saveQBtn);

        JPanel resultsPanel = new JPanel(new BorderLayout());
        resultsPanel.setBackground(new Color(11, 15, 25));
        resultsListModel = new DefaultListModel<>();
        JList<String> resultsList = new JList<>(resultsListModel);
        resultsList.setBackground(new Color(17, 24, 39));
        resultsList.setForeground(Color.WHITE);
        resultsPanel.add(new JScrollPane(resultsList), BorderLayout.CENTER);
        JButton refreshResults = new JButton("Refresh Submissions");
        refreshResults.addActionListener(e -> {
            resultsListModel.clear();
            for (String[] res : submissionResults) {
                resultsListModel.addElement("Student: " + res[0] + " | Status: " + res[1] + " | Warnings: " + res[2] + " | Score: " + res[3]);
            }
        });
        resultsPanel.add(refreshResults, BorderLayout.SOUTH);

        adminTabs.add("Live Monitor", livePanel);
        adminTabs.add("Add Questions", addQPanel);
        adminTabs.add("Results & Grading", resultsPanel);

        panel.add(adminTabs, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createStudentFeedCard(String name, String status, String warnings) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(new Color(31, 41, 55));
        card.setBorder(BorderFactory.createLineBorder(new Color(55, 65, 81), 1));
        JLabel header = new JLabel(" [LIVE] " + name + " (" + status + ")");
        header.setForeground(Color.WHITE);
        JLabel meta = new JLabel(" Warnings: " + warnings + " ");
        meta.setForeground(new Color(245, 158, 11));
        
        JPanel screenMock = new JPanel();
        screenMock.setBackground(Color.BLACK);
        JLabel screenText = new JLabel("[Live Screen Stream]");
        screenText.setForeground(Color.GRAY);
        screenMock.add(screenText);

        JPanel actions = new JPanel(new FlowLayout());
        actions.setOpaque(false);
        JButton warnBtn = new JButton("Send Warning");
        warnBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "Warning pushed to " + name));
        actions.add(warnBtn);

        card.add(header, BorderLayout.NORTH);
        card.add(screenMock, BorderLayout.CENTER);
        card.add(meta, BorderLayout.WEST);
        card.add(actions, BorderLayout.SOUTH);
        return card;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new JavaAssessmentApp().setVisible(true);
        });
    }
}
