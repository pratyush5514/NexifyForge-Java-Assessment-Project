const defaultQuestions = [
  {
    id: 1,
    title: 'Palindrome Check',
    desc: 'Write a Java program inside Solution.main() that checks if "racecar" is a palindrome and prints true.',
    starter: 'public class Solution {\n    public static void main(String[] args) {\n        String s = "racecar";\n        boolean isPal = s.equals(new StringBuilder(s).reverse().toString());\n        System.out.println(isPal);\n    }\n}'
  },
  {
    id: 2,
    title: 'JVM Memory Concept',
    desc: 'Which memory area stores class metadata in Java 8+?',
    options: ['Heap Space', 'Metaspace', 'Stack'],
    answer: 'Metaspace'
  }
];

let questions = JSON.parse(localStorage.getItem('nf_questions') || 'null') || defaultQuestions;
let currentRole = 'student';
let currentUser = 'student01';
let currentQIdx = 0;
let warnings = 0;
let examActive = false;
let studentStream = null;
let mediaRecorder = null;
let recordedChunks = [];
let timerInterval = null;
let secondsLeft = 45 * 60;

function toggleAdvanced() {
  const p = document.getElementById('advanced-panel');
  p.style.display = p.style.display === 'block' ? 'none' : 'block';
}

function switchView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function setLoginRole(role) {
  currentRole = role;
  document.getElementById('tab-student').classList.toggle('active', role === 'student');
  document.getElementById('tab-admin').classList.toggle('active', role === 'admin');
  document.getElementById('login-user').value = role === 'student' ? 'student01' : 'admin';
  document.getElementById('login-pass').value = role === 'student' ? 'pass123' : 'admin123';
}

function handleLogin() {
  const u = document.getElementById('login-user').value.trim();
  const p = document.getElementById('login-pass').value.trim();
  if (currentRole === 'student' && u === 'student01' && p === 'pass123') {
    currentUser = u;
    switchView('view-preflight');
  } else if (currentRole === 'admin' && u === 'admin' && p === 'admin123') {
    currentUser = u;
    switchView('view-admin');
    renderResults();
  } else {
    alert('Invalid credentials. Use student01/pass123 or admin/admin123.');
  }
}

async function startExam() {
  try {
    studentStream = await navigator.mediaDevices.getDisplayMedia({ video: { displaySurface: 'monitor' } });
    document.getElementById('admin-preview-video').srcObject = studentStream;
  } catch (e) {
    alert('Entire screen sharing is required to start the exam.');
    return;
  }

  if (document.documentElement.requestFullscreen) {
    document.documentElement.requestFullscreen().catch(() => {});
  }

  recordedChunks = [];
  mediaRecorder = new MediaRecorder(studentStream, { mimeType: 'video/webm' });
  mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) recordedChunks.push(e.data); };
  mediaRecorder.start(1000);

  examActive = true;
  warnings = 0;
  secondsLeft = 45 * 60;
  document.getElementById('candidate-name-badge').textContent = `Candidate: ${currentUser}`;
  switchView('view-exam');
  renderQuestionNav();
  loadQuestion(0);
  startTimer();
}

function startTimer() {
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    secondsLeft--;
    const m = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
    const s = String(secondsLeft % 60).padStart(2, '0');
    document.getElementById('exam-timer').textContent = `${m}:${s}`;
    if (secondsLeft <= 0) submitExam('Time Expired');
  }, 1000);
}

window.addEventListener('blur', () => {
  if (examActive) triggerViolation('Tab switch or focus loss detected!');
});

function triggerViolation(reason) {
  if (!examActive) return;
  warnings++;
  document.getElementById('warning-counter').textContent = `Warnings: ${warnings} / 3`;
  document.getElementById('ai-risk').textContent = warnings === 1 ? 'Medium (50%)' : 'High (95%)';
  document.getElementById('ai-risk').style.color = 'var(--danger)';

  if (warnings >= 3) {
    submitExam('Auto-Submitted: 3 Tab Switches Exceeded');
    return;
  }

  document.getElementById('warning-msg').textContent = reason;
  document.getElementById('modal-warn-num').textContent = warnings;
  document.getElementById('warning-modal').classList.add('active');
}

function dismissWarning() {
  document.getElementById('warning-modal').classList.remove('active');
  if (document.documentElement.requestFullscreen && !document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(() => {});
  }
}

function renderQuestionNav() {
  const nav = document.getElementById('q-nav');
  nav.innerHTML = '';
  questions.forEach((q, i) => {
    const btn = document.createElement('button');
    btn.className = 'q-btn' + (i === currentQIdx ? ' active' : '');
    btn.textContent = i + 1;
    btn.onclick = () => loadQuestion(i);
    nav.appendChild(btn);
  });
}

function loadQuestion(idx) {
  currentQIdx = idx;
  renderQuestionNav();
  const q = questions[idx];
  document.getElementById('q-title').textContent = `Q${idx + 1}. ${q.title}`;
  document.getElementById('q-desc').textContent = q.desc;
  const mcqBox = document.getElementById('mcq-options');
  const editor = document.getElementById('java-editor');

  if (q.options) {
    mcqBox.innerHTML = '';
    editor.style.display = 'none';
    q.options.forEach(opt => {
      mcqBox.innerHTML += `<label style="background:var(--bg-card); padding:10px; border-radius:6px; cursor:pointer;"><input type="radio" name="mcq" value="${opt}"> ${opt}</label>`;
    });
  } else {
    mcqBox.innerHTML = '';
    editor.style.display = 'block';
    editor.value = q.starter;
  }
}

function runJavaCode() {
  const code = document.getElementById('java-editor').value;
  const consoleEl = document.getElementById('java-console');
  if (code.includes('racecar')) {
    consoleEl.textContent = '[Simulated JDK 17 Execution]\ntrue\nProcess finished with exit code 0';
  } else {
    consoleEl.textContent = '[Simulated JDK 17 Execution]\nCompiled successfully.\nProcess finished with exit code 0';
  }
}

function askAI() {
  const input = document.getElementById('ai-input');
  if (!input.value.trim()) return;
  const log = document.getElementById('ai-chat-log');
  log.innerHTML += `<div class="ai-msg user">${input.value}</div>`;
  input.value = '';
  setTimeout(() => {
    log.innerHTML += `<div class="ai-msg"><strong>Nexify AI:</strong> Ensure your public class is named <code>Solution</code> and ends statements with semicolons.</div>`;
    log.scrollTop = log.scrollHeight;
  }, 300);
}

async function submitExam(reason) {
  if (!examActive) return;
  examActive = false;
  clearInterval(timerInterval);

  if (mediaRecorder && mediaRecorder.state !== 'inactive') {
    mediaRecorder.stop();
    await new Promise(r => setTimeout(r, 300));
  }
  if (studentStream) studentStream.getTracks().forEach(t => t.stop());

  const blob = new Blob(recordedChunks, { type: 'video/webm' });
  const videoUrl = URL.createObjectURL(blob);

  const results = JSON.parse(localStorage.getItem('nf_results') || '[]');
  results.unshift({
    student: currentUser,
    status: reason,
    warnings: `${warnings}/3`,
    score: warnings >= 3 ? '40% (Flagged)' : '88%',
    videoUrl
  });
  localStorage.setItem('nf_results', JSON.stringify(results));

  alert(`Exam Submitted!\nStatus: ${reason}`);
  switchView('view-login');
}

function switchAdminTab(tab, el) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('admin-tab-live').style.display = tab === 'live' ? 'block' : 'none';
  document.getElementById('admin-tab-questions').style.display = tab === 'questions' ? 'block' : 'none';
  document.getElementById('admin-tab-results').style.display = tab === 'results' ? 'block' : 'none';
  if (tab === 'results') renderResults();
}

function addQuestion() {
  const title = document.getElementById('new-q-title').value.trim();
  const desc = document.getElementById('new-q-desc').value.trim();
  const starter = document.getElementById('new-q-starter').value;
  if (!title) return alert('Title required');
  questions.push({ id: Date.now(), title, desc, starter });
  localStorage.setItem('nf_questions', JSON.stringify(questions));
  alert('Question added successfully!');
  document.getElementById('new-q-title').value = '';
  document.getElementById('new-q-desc').value = '';
}

function renderResults() {
  const tbody = document.getElementById('results-tbody');
  const results = JSON.parse(localStorage.getItem('nf_results') || '[]');
  if (results.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="color:var(--text-muted);">No submissions yet.</td></tr>';
    return;
  }
  tbody.innerHTML = results.map(r => `
    <tr>
      <td><strong>${r.student}</strong></td>
      <td>${r.status}</td>
      <td>${r.warnings}</td>
      <td><strong>${r.score}</strong></td>
      <td>${r.videoUrl ? `<button class="btn-primary" style="padding:4px 10px; font-size:11px;" onclick="watchRecording('${r.videoUrl}')">Watch Video</button>` : 'N/A'}</td>
    </tr>
  `).join('');
}

function watchRecording(url) {
  const box = document.getElementById('video-playback-box');
  const player = document.getElementById('recorded-player');
  box.style.display = 'block';
  player.src = url;
  player.play();
}
